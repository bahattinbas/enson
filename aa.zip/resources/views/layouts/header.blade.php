<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{ asset('css/ilk.css') }}">
  </head>


    <div class="üst">
      <img src="{{asset('resimler/logorgb.png')}}" height="150px" width="150px" >

    </div>
    <div class="üst" >
      <center>
      KOCAELİ ÜNİVERSİTESİ YAZLAB PROJESİ</center>
    </div>


</html>
