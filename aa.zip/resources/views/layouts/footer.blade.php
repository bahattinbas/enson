<div>
<p><center> @2021 Tüm Hakları Saklıdır.. MZ </p>
</div>
<style media="screen">
  f {
    position: fixed;
    bottom: 0px;
    left: 0px;
    width: 100%;
    height: 50px;
    padding:15px;
}
</style>
